var xmlrpc=null;

try{
    var xmlrpc = importModule("xmlrpc");
}catch(e){
    reportException(e);
    alert("importing of xmlrpc module failed.");
    throw "importing of xmlrpc module failed.";
}

var widgetWidth = 197;
var widgetHeight = 74;
var debug = false;
var myTimer;
var pulse = 1000 * 30;
var metaData = null;
var serverKey = null;
var addr = "http://xmlrpc.secondlife.com/cgi-bin/xmlrpc.cgi";
    

function send_rpc(method){
    var sString = method;
    if ( window.widget && serverKey == null) 
    {
        serverKey = widget.preferenceForKey(makeKey("serverKey"));
    }
    
    if ( serverKey != null )
    {
        var params = {Channel : serverKey, StringValue : sString, IntValue : 1};
        
        if (debug) alert("querying server : " + params.Channel + " : " + params.StringValue + " : " + params.IntValue);
        
        try{
            var service = new xmlrpc.ServiceProxy(addr,['llRemoteData']);
            var rslt = service.llRemoteData(params);
            if (debug) alert("String Result: " + rslt["StringValue"]);  // Returns String Value
            if (debug) alert("Integer Result: " + rslt["IntValue"]);  // Returns Int Value
            return rslt["StringValue"].split("\n");
        }catch(e){
            var em;
            if(e.toTraceString){
                em=e.toTraceString();
            }else{
                em = e.message;
            }
            alert("Error trace: \n\n" + em);
            stop();
        }
    }
    return false;
}

// utility for debugging
function dump_props(obj, obj_name) {
   var result = "";
   for (var i in obj) {
      result += obj_name + "." + i + " = " + obj[i] + "\n"
   }
   alert(result);
}

function get_xmldata() {
    var addr = "http://secondlife.com/xmlhttp/secondlife.php";
    
    xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET",addr,true);
    xmlhttp.onreadystatechange=function() {
        if (xmlhttp.readyState==4) {
            //alert(xmlhttp.responseText);
            var response = xmlhttp.responseXML.documentElement;
            document.getElementById('population').innerHTML = response.getElementsByTagName('population')[0].firstChild.data;
            document.getElementById('transactions').innerHTML = response.getElementsByTagName('transactions')[0].firstChild.data;
            document.getElementById('inworld').innerHTML = response.getElementsByTagName('inworld')[0].firstChild.data;
        }
    }
    xmlhttp.send(null);
}

function refresh_friends() {
    parent.friends.location.href="http://secondlife.com/community/friends-iframe.php";
}
function makeKey(key)
{
	return widget.identifier + "-" + key;
}

function stop() 
{
    if ( debug) alert("stopping");
    clearTimeout(myTimer);
}

function run()
{
    get_xmldata();
    refresh_friends();
    if ( serverKey != null ) {
        if ( metaData == null ) {
            metaData = send_rpc("meta");  
            document.getElementById('meta').innerHTML = metaData[1] + " - " + metaData[3] + "<br>" + metaData[2];
        }
        simData = send_rpc("sim");
        document.getElementById('time').innerHTML = simData[0];
        document.getElementById('fps').innerHTML = simData[1];
        document.getElementById('dialation').innerHTML = simData[2];
        document.getElementById('wind').innerHTML = simData[3];
        document.getElementById('cloudy').innerHTML = simData[4];
        visitData = send_rpc("visitors");
        document.getElementById('visitors').innerHTML = visitData[0];
    } else {
        document.getElementById('meta').innerHTML = "<a href='secondlife://Carmine/112/128'\">Get the ingame widget server</a>"
                                + " to see interesting data from your location";
    }
    clearTimeout(myTimer); // There was the possibility of problems,better safe than sorry.
    myTimer = setTimeout('run()',pulse);
}

function setup(x,y)
{
	if(window.widget)
	{
        if (debug) alert("setup called for widget");
        window.resizeTo(widgetWidth, widgetHeight);
        if ( window.widget ) 
        {
            serverKey = widget.preferenceForKey(makeKey("serverKey"));
            document.getElementById('serverKey').value = serverKey;
        }
	}
    run();
}


function changeKey(elem)
{	
    if (debug) alert("setting server key- got here");
    stop();
	serverKey = document.getElementById("serverKey").value;	// the frame element is obtained
          
	if(window.widget)
	{
        if (debug) alert("setting server key to " + serverKey);
		widget.setPreferenceForKey(serverKey,makeKey("serverKey"));
	}
}  


// onremove clears away any preferences that this widget may have had.

function onremove()
{
    stop();
    if (debug) alert("onremove()");
	widget.setPreferenceForKey(null,makeKey("serverKey"));
}

function onshow()
{
   if (debug) alert("onshow()"); 
   window.resizeTo(widgetWidth, widgetHeight);
   run();
}

function onhide()
{
    if (debug) alert("onhide()");
    stop();
}

// this is where widget-specific handlers can be declared.  This widget only uses one;
// it is called when the widget is removed from Dashbaord

if(window.widget)
{
	widget.onremove = onremove;
    widget.onshow = onshow;
    widget.onhide = onhide;
}
